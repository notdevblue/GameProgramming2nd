public struct Coord
{
    int x;
    int y;
};